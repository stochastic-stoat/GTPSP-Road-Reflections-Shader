// PPSSPP Wet Roads Reflection
// By Stochastic Stoat
//
// Based on Fake Reflections Shader by Henrik Rydgård
// Fixed reflection controls:
//   Amount = 1.00
//   Power  = 0.07
//
// Slider mapping:
//   u_setting.x = Vertical Offset
//   u_setting.y = Vertical Compression
//   u_setting.z = Image Warp Strength
//   u_setting.w = Reflection Gate (higher = stricter road-color match)
//
// Distortion is driven by the source image's own color/luminance instead of
// a random noise texture. This is still a screen-space approximation.

#ifdef GL_ES
precision mediump float;
precision mediump int;
#endif

uniform sampler2D sampler0;
varying vec2 v_texcoord0;
uniform vec4 u_setting;
uniform float u_vr;

float luminance(vec3 c)
{
    return dot(c, vec3(0.299, 0.587, 0.114));
}

float colorDistance(vec3 a, vec3 b)
{
    return length(a - b);
}

void main()
{
    vec2 uv = v_texcoord0;
    vec2 texel = vec2(1.0 / 512.0, 1.0 / 272.0);

    vec3 color = texture2D(sampler0, uv).rgb;
    float gray = luminance(color);
    float saturation = (
        abs(color.r - gray) +
        abs(color.g - gray) +
        abs(color.b - gray)
    ) / 3.0;

    float scale = 1.0 + u_vr;
    float height = clamp(uv.y, 0.0, 1.0);
    float fade = smoothstep(0.12, 0.92, height);

    // 1. Edge detection first. Suppresses reflection at strong boundaries.
    vec3 left1  = texture2D(sampler0, uv - vec2(texel.x, 0.0)).rgb;
    vec3 right1 = texture2D(sampler0, uv + vec2(texel.x, 0.0)).rgb;
    vec3 up1    = texture2D(sampler0, uv - vec2(0.0, texel.y)).rgb;
    vec3 down1  = texture2D(sampler0, uv + vec2(0.0, texel.y)).rgb;

    vec3 left3  = texture2D(sampler0, uv - vec2(texel.x * 3.0, 0.0)).rgb;
    vec3 right3 = texture2D(sampler0, uv + vec2(texel.x * 3.0, 0.0)).rgb;
    vec3 up3    = texture2D(sampler0, uv - vec2(0.0, texel.y * 3.0)).rgb;
    vec3 down3  = texture2D(sampler0, uv + vec2(0.0, texel.y * 3.0)).rgb;

    float edgeFine = abs(luminance(right1) - luminance(left1))
                   + abs(luminance(down1) - luminance(up1));
    float edgeWide = abs(luminance(right3) - luminance(left3))
                   + abs(luminance(down3) - luminance(up3));
    float edge = clamp(edgeFine * 2.0 + edgeWide * 1.25, 0.0, 1.0);
    float edgeProtection = 1.0 - edge * 0.62;

    // 2. Reflection transform.
    float verticalOffset = u_setting.x;
    float verticalCompression = max(u_setting.y, 0.10);
    // Expanded range allows intentionally extreme horizontal warping.
    float warpStrength = max(u_setting.z, 0.0);

    vec2 reflectedUV;
    reflectedUV.x = uv.x;
    reflectedUV.y = 0.5 + ((1.0 - uv.y) - 0.5) * verticalCompression;
    reflectedUV.y += verticalOffset;

    // 3. Image-driven distortion:
    // Sample the source image at several nearby positions. Its luminance and
    // channel differences drive the warp, so high-contrast texture produces
    // more jagged distortion while flatter areas remain steadier.
    vec3 warpLeft  = texture2D(sampler0, clamp(uv - vec2(texel.x * 2.0, 0.0), vec2(0.001), vec2(0.999))).rgb;
    vec3 warpRight = texture2D(sampler0, clamp(uv + vec2(texel.x * 2.0, 0.0), vec2(0.001), vec2(0.999))).rgb;
    vec3 warpUp    = texture2D(sampler0, clamp(uv - vec2(0.0, texel.y * 2.0), vec2(0.001), vec2(0.999))).rgb;
    vec3 warpDown  = texture2D(sampler0, clamp(uv + vec2(0.0, texel.y * 2.0), vec2(0.001), vec2(0.999))).rgb;

    float horizontalTexture = luminance(warpRight) - luminance(warpLeft);
    float verticalTexture = luminance(warpDown) - luminance(warpUp);
    float chromaTexture = (warpRight.r - warpLeft.r) - (warpDown.b - warpUp.b);

    // Mild base distortion from the existing shader plus image-derived warp.
    float rndx = mod(uv.x + gray, 0.03 * scale)
               + mod(uv.y + saturation, 0.05 * scale);
    float rndy = mod(uv.y + saturation, 0.03 * scale)
               + mod(uv.x + gray, 0.05 * scale);
    float baseDistortion = 0.25 + max(gray, saturation);
    vec2 legacyOffset = vec2(rndx, rndy) * baseDistortion * fade * 0.30;

    // Horizontal component is deliberately amplified much more than v6.
    // The slider's new range is 0..0.50 (v6 was 0..0.08).
    vec2 imageWarp = vec2(
        (horizontalTexture * 1.65 + chromaTexture * 0.85) * 2.8,
        (verticalTexture * 0.85 - chromaTexture * 0.25) * 1.25
    ) * warpStrength * scale;

    // Slightly stronger horizontal warping gives a jagged/watery look.
    reflectedUV += legacyOffset + imageWarp;
    reflectedUV = clamp(reflectedUV, vec2(0.001), vec2(0.999));
    vec3 reflection = texture2D(sampler0, reflectedUV).rgb;

    // 4. Road color bias and grass/dirt exclusions.
    vec3 roadColor = vec3(65.0, 64.0, 64.0) / 255.0; // #414040
    float roadDistance = colorDistance(color, roadColor);
    // Gate is a hard cutoff on the road-color match. At 0, v6's original
    // broad road bias is preserved. Raising it makes the match stricter and
    // can abruptly remove reflections from pixels that don't match the road.
    // It does not alter reflection brightness/clarity.
    float gate = clamp(u_setting.w, 0.0, 1.0);
    float roadTolerance = mix(0.20, 0.025, gate);
    float roadMatch = 1.0 - smoothstep(
        roadTolerance * 0.45, roadTolerance, roadDistance
    );
    float roadBias = mix(0.30, 1.0, roadMatch);
    if (gate > 0.001 && roadMatch < 0.5) {
        roadBias = 0.0;
    }

    vec3 grass1 = vec3(48.0, 54.0, 15.0) / 255.0; // #30360F
    vec3 grass2 = vec3(76.0, 68.0, 32.0) / 255.0; // #4C4420
    vec3 grass3 = vec3(77.0, 78.0, 39.0) / 255.0; // #4D4E27
    vec3 dirt   = vec3(95.0, 67.0, 52.0) / 255.0; // #5F4334;

    float grassMatch = max(
        1.0 - smoothstep(0.06, 0.22, colorDistance(color, grass1)),
        max(
            1.0 - smoothstep(0.06, 0.22, colorDistance(color, grass2)),
            1.0 - smoothstep(0.06, 0.22, colorDistance(color, grass3))
        )
    );
    float dirtMatch = 1.0 - smoothstep(
        0.06, 0.22, colorDistance(color, dirt)
    );
    float exclusion = max(grassMatch, dirtMatch);
    float colorProtection = 1.0 - exclusion * 0.90;

    // Fixed values requested by user: Amount=1.00, Power=0.07.
    reflection *= 4.0 * (1.0 - gray) * 1.00;
    reflection *= reflection * 0.07;

    float finalMask = edgeProtection * roadBias * colorProtection;
    reflection *= fade * finalMask;

    gl_FragColor = vec4(clamp(color + reflection, 0.0, 1.0), 1.0);
}
